<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class=" row col-12">
            <div class="float-right">
                <div class="form-group">
                    <div class="btn-group btn-group-sm" role="group">
                        <?php if(Auth::user()->hasRole("admin")): ?>
                        <button type="button" onclick='location.href="<?php echo e(route('createUser', app()->getLocale())); ?>"' class="btn btn-success"><i class="fas fa-user-check"></i>Create New User</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">User list</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">User ID</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Operations</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role->display_name); ?></td>
                                    <td>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-sm" role="group">


                                                    <button type="button" onclick='location.href="<?php echo e(route('editUser', [app()->getLocale(), $user->id] )); ?>"' class="btn btn-info"><i class="fas fa-edit"></i> Edit</button>
                                                    <button type="button" onclick="location.href='#'" class="btn btn-success"><i class="fas fa-eye"></i> View</button>
                                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                                    <button type="button" onclick='location.href="<?php echo e(route('deleteUser', [app()->getLocale(), $user->id] )); ?>"' class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\newLaravel\resources\views/users.blade.php ENDPATH**/ ?>