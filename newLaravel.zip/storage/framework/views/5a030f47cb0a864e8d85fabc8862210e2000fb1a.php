<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class=" row col-12">
            <div class="float-right">
                <div class="form-group">
                    <div class="btn-group btn-group-sm" role="group">
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Balance History -> Client : <span class="badge badge-primary"> <?php echo e($client->name); ?> </span></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                            <table id="PaymentsTable" class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Source</th>
                                    <th scope="col">By User</th>
                                    <th scope="col">Old Balance</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Balance</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($transaction->created_at); ?></td>
                                    <td><?php echo e($transaction->source); ?></td>
                                    <td><?php echo e($transaction->user->name); ?></td>
                                    <td><?php echo e($transaction->pivot->old_balance); ?></td>
                                    <td>+ <?php echo e($transaction->amount); ?></td>
                                    <td><?php echo e($transaction->pivot->new_amount); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\newLaravel\resources\views/transactions.blade.php ENDPATH**/ ?>