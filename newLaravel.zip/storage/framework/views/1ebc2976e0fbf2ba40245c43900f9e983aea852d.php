<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class=" row col-12">
            <div class="float-right">
                <div class="form-group">
                    <div class="btn-group btn-group-sm" role="group">
                        <?php if(Auth::user()->hasRole("admin") || Auth::user()->hasRole("accountant")): ?>
                        <button type="button" onclick='location.href="<?php echo e(route('createPayment', app()->getLocale())); ?>"' class="btn btn-success"><i class="fas fa-plus"></i> New Payment</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="input-group mb-3">
                <input id="query" name="query" type="text" class="form-control" placeholder="Search by User ID#" aria-label="Search by Client ID#" aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <button id="btn-search" class="btn btn-outline-secondary" type="button"><i id="preloader" class="fas fa-search"></i> Search</button>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Payments list</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                            <table id="PaymentsTable" class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">Client</th>
                                    <th scope="col">By User</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Source</th>
                                    <th scope="col">Status</th>
                                    <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole("accountant")): ?>
                                        <th scope="col">Operations</th>
                                    <?php endif; ?>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($payment->amount); ?></td>
                                    <td>
                                        <?php if(Auth::user()->hasRole('operator')): ?>
                                            <?php echo e($payment->client->id); ?>

                                        <?php else: ?>
                                            <?php echo e($payment->client->name); ?>

                                        <?php endif; ?>
                                       </td>
                                    <td><?php echo e($payment->user->name); ?></td>
                                    <td><?php echo e($payment->created_at); ?></td>
                                    <td><?php echo e($payment->source); ?></td>
                                    <td><?php echo e($payment->statusLabel()); ?></td>
                                    <td>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-sm" role="group">

                                                    <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole("accountant")): ?>
                                                    <button type="button" onclick="location.href='#'" class="btn btn-info"><i class="fas fa-edit"></i> Edit</button>
                                                    <button type="button" onclick='location.href="<?php echo e(route('deletePayment', [app()->getLocale(), $payment->id] )); ?>"' class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\newLaravel\resources\views/payments.blade.php ENDPATH**/ ?>