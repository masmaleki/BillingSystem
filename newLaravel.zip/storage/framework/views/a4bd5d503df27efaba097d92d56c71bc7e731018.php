<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class=" row col-12">
            <div class="float-right">
                <div class="form-group">
                    <div class="btn-group btn-group-sm" role="group">
                        <?php if(Auth::user()->hasRole("admin")  || Auth::user()->hasRole("operator")): ?>
                        <button type="button" onclick='location.href="<?php echo e(route('createClient', app()->getLocale())); ?>"' class="btn btn-success"><i class="fas fa-plus"></i> New Client</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if(Auth::user()->hasRole("admin")  || Auth::user()->hasRole("accountant")): ?>
            <div class="input-group mb-3">
                <input id="query" name="query" type="text" class="form-control" placeholder="Search Client" aria-label="Search by Client ID#" aria-describedby="basic-addon2">
                <div class="input-group-append">
                    <button id="btn-search-client" class="btn btn-outline-secondary" type="button"><i id="preloader" class="fas fa-search"></i> Search</button>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Clients list</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                            <?php if(! Auth::user()->hasRole('operator')): ?>
                            <table id="ClientTable" class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Tel</th>
                                    <th scope="col">Balance</th>
                                    <th scope="col">Operations</th>
                                </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($client->name); ?></td>
                                    <?php if( Auth::user()->hasRole('admin')): ?>
                                        <td><?php echo e($client->email); ?></td>
                                        <td><?php echo e($client->tell); ?></td>
                                    <?php else: ?>
                                        <td>******</td>
                                        <td>******</td>
                                    <?php endif; ?>
                                    <td><?php echo e($client->balance); ?></td>
                                    <td>
                                        <div class="form-group">
                                            <div class="btn-group btn-group-sm" role="group">

                                                <?php if( Auth::user()->hasRole('admin')): ?>
                                                    <button type="button" onclick="location.href='#'" class="btn btn-info"><i class="fas fa-edit"></i> Edit</button>
                                                    <button type="button" onclick="location.href='#'" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                                                <?php endif; ?>
                                                    <button type="button" onclick='location.href="<?php echo e(route('paymentHistory', [app()->getLocale(), $client->id] )); ?>"' class="btn btn-warning"><i class="fas fa-eye"></i> Balance History</button>



                                            </div>
                                        </div>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            <?php else: ?>
                                <div class="alert alert-danger" role="alert">
                                    You have Not Access to View Clients
                                </div>


                            <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\newLaravel\resources\views/clients.blade.php ENDPATH**/ ?>